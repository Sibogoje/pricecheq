<div class="header" onclick="event.stopPropagation()">
        <span class="menu-icon" onclick="toggleSidebar()">&#9776;</span>
        <h3>BIKA</h3>
        <img src="bika logo.png" alt="Transport Logo" class="logo">
    </div>
    
    <div id="sidebar" class="sidebar" onclick="event.stopPropagation()">
        <span class="close-btn" onclick="hideSidebar()">&#10005;</span>
        <div class="sidebar-logo">
            <img src="bika logo.png" alt="Transport Logo">
        </div>
        <a href="index.php">Home</a>
        <a href="#">Partners</a>
        <a href="about.php">About</a>
    </div>